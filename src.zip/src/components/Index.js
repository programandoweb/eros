import Home from "./Home";
import Dialog from "./Dialog";
import Splash from "./Splash";
import QuestionAge from "./QuestionAge";
import NotAgePermited from "./NotAgePermited";
import Auth from "./Auth/Index";
export {
  Home,
  Dialog,
  Splash,
  QuestionAge,
  NotAgePermited,
  Auth,
}
