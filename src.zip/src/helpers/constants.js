export default{
  Development : 'ProgramandoWeb',
  Title:'InStore',
  LogoSm:'./images/ico-md.png',
  View:'Title',  //Title
}
